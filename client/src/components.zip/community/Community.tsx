import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAppSelector, useAppDispatch } from "../../store/hooks";
import { fetchCommunityPostsThunk } from "../../store/userSlice";
import "../css/Community.css";
import "../css/Header.css";
import Community_Find from "./Community_find";
import Community_Stats from "./Community_stats";
import CommunityAll from "./Community_all";
import Header from "../../components/Header";
import flag from "../../assets/community_flag.svg";
import plus from "../../assets/plus_icon.svg";
import find from "../../assets/find_icon.svg";
import bell from "../../assets/bell_icon.svg";

const Community = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const [likedPosts, setLikedPosts] = useState<number[]>([]);
  const [isSearchMode, setIsSearchMode] = useState(false);
  const [currentSection, setCurrentSection] = useState("default");
  const posts = useAppSelector((state) => state.user.communityPosts);
  const safePosts = Array.isArray(posts) ? posts : [];
  console.log(posts);

  useEffect(() => {
    dispatch(fetchCommunityPostsThunk());
  }, [dispatch]);

  // 인기 TOP3
  const popularPosts = safePosts.slice(0, 3);
  // 최근 게시물
  const recentPosts = safePosts;

  const handleLike = (postId: number) => {
    setLikedPosts((prev) =>
      prev.includes(postId)
        ? prev.filter((id) => id !== postId)
        : [...prev, postId]
    );
  };

  const handleSearchClick = () => {
    setIsSearchMode(true);
  };

  const handleViewAllClick = () => {
    setIsSearchMode(false);
    setCurrentSection("all");
    window.scrollTo({ top: 0, behavior: "instant" });
  };

  return (
    <>
      {isSearchMode ? (
        <Community_Find onBack={() => setIsSearchMode(false)} />
      ) : currentSection === "all" ? (
        <CommunityAll onBack={() => setCurrentSection("default")} />
      ) : (
        <>
          <Header
            title="커뮤니티"
            rightIcons={[
              {
                icon: <img src={plus} alt="plus icon" />,
                onClick: () => navigate("/community/write"),
              },
              {
                icon: <img src={find} alt="find icon" />,
                onClick: handleSearchClick,
              },
              {
                icon: <img src={bell} alt="bell icon" />,
                onClick: () => console.log("알림"),
              },
            ]}
          />
          <div className="community-container">
            <section className="community-top-ui">
              <header className="community-header">
                <div>
                  <img src={flag} alt="community flag" />
                  <h2>WALKEE 커뮤니티 이용 가이드 보기</h2>
                </div>
                <p>{">"}</p>
              </header>
            </section>

            {/* 인기 TOP3 */}
            <section className="popular-section">
              <h3>인기 TOP3</h3>
              <div className="popular-scroll-wrapper">
                <div className="popular-cards">
                  {popularPosts.map((post) => (
                    <div key={post.postIdx} className="post-card">
                      <div className="profile-header">
                        <img src={post.userProfile || ""} className="post-profile" />
                        <span className="username">{post.userName}</span>
                      </div>
                      {post.postUploadImg && (
                        <img src={`${import.meta.env.VITE_APP_API_URL}/api/public${post.postUploadImg}`} className="map-image" />
                      )}
                      <div className="post-info">
                        <p className="post-title">{post.postTitle}</p>
                        <div className="post-meta">
                          <span className="post-date">{post.postCreatedAt?.slice(0, 10)}</span>
                          <Community_Stats
                            views={post.postCount}
                            comments={0}
                            initialLikes={post.likeCount}
                            postId={post.postIdx}
                            isLiked={likedPosts.includes(post.postIdx)}
                            onLike={handleLike}
                            variant="popular"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </section>

            {/* 최근 게시물 */}
            <section className="recent-section">
              <h3>최근 게시물</h3>
              {recentPosts.map((post) => (
                <div key={post.postIdx} className="recent-post">
                  <div className="recent-post-top">
                    <div className="recent-post-left">
                      <div className="user-info">
                        <span className="username">{post.userName}</span>
                        <span className="date">{post.postCreatedAt?.slice(0, 10)}</span>
                      </div>
                      <h4 className="title">{post.postTitle}</h4>
                      <Community_Stats
                        views={post.postCount}
                        comments={0}
                        initialLikes={post.likeCount}
                        postId={post.postIdx}
                        isLiked={likedPosts.includes(post.postIdx)}
                        onLike={handleLike}
                      />
                    </div>
                    <div className="recent-post-right">
                      {post.postUploadImg ? (
                        <img
                          src={`${import.meta.env.VITE_APP_API_URL}/api/public${post.postUploadImg}`}
                          alt="post"
                          className="recent-post-map"
                        />
                      ) : (
                        <div className="no-image-placeholder"></div>
                      )}
                    </div>
                  </div>
                  <div className="recent-post-bottom">
                    <p className="content">{post.postContent}</p>
                  </div>
                </div>
              ))}
              <button className="view-all-button" onClick={handleViewAllClick}>
                게시물 전체보기
              </button>
            </section>
          </div>
        </>
      )}
    </>
  );
};

export default Community;
